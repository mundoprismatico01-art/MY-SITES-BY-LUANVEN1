# Oração Subordinada Substantiva. O que é?

A Pen created on CodePen.

Original URL: [https://codepen.io/luanven1/pen/KwgLOoG](https://codepen.io/luanven1/pen/KwgLOoG).

