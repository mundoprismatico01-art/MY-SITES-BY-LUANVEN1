# Oração Subordinada Adjetiva

A Pen created on CodePen.

Original URL: [https://codepen.io/luanven1/pen/YPGdPRM](https://codepen.io/luanven1/pen/YPGdPRM).

